package com.developerrr.loundryapp.constants;



// to shows you the step you have done
public class StepSingleton {

    public static boolean StepOneCompleted;
    public static boolean StepTwoCompleted;
    public static boolean StepThreeCompleted;
    public static boolean StepFourCompleted;

}
