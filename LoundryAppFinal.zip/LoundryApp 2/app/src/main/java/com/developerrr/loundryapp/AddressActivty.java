package com.developerrr.loundryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.developerrr.loundryapp.constants.Constants;
import com.developerrr.loundryapp.constants.StepSingleton;


// new address page

public class AddressActivty extends AppCompatActivity implements View.OnClickListener {

    Button saveAddressBtn;

    TextView apt, office, villa, hotel;
    EditText buildingEt, appartmentEt, notesEt;

    SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_address_activty);

        saveAddressBtn = findViewById(R.id.saveAddressBtn);
        apt = findViewById(R.id.address_apt);
        office = findViewById(R.id.address_office);
        villa = findViewById(R.id.address_villa);
        hotel = findViewById(R.id.address_hotel);

        editor = getSharedPreferences(Constants.prefsName, MODE_PRIVATE).edit();

        buildingEt = findViewById(R.id.building_et);
        appartmentEt = findViewById(R.id.apartment_et);
        notesEt = findViewById(R.id.notes_et);

        setSelected(apt);

        apt.setOnClickListener(this);
        office.setOnClickListener(this);
        villa.setOnClickListener(this);
        hotel.setOnClickListener(this);
        saveAddressBtn.setOnClickListener(this);


    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.saveAddressBtn:
                validateAndSaveAddress();
                break;
            case R.id.address_apt:
                setSelected(apt);
                break;
            case R.id.address_villa:
                setSelected(villa);
                break;
            case R.id.address_office:
                setSelected(office);
                break;
            case R.id.address_hotel:
                setSelected(hotel);
                break;
        }
    }

    private void validateAndSaveAddress() {
        if (!TextUtils.isEmpty(buildingEt.getText().toString().trim())
                && !TextUtils.isEmpty(appartmentEt.getText().toString().trim())) {
            if(!TextUtils.isEmpty(notesEt.getText().toString())){
                editor.putString(Constants.addressBuilding,buildingEt.getText().toString());
                editor.putString(Constants.addressAppartment,appartmentEt.getText().toString());
                editor.putString(Constants.addressNotes,notesEt.getText().toString());
                editor.commit();
                editor.apply();
            }else {
                editor.putString(Constants.addressBuilding,buildingEt.getText().toString());
                editor.putString(Constants.addressAppartment,appartmentEt.getText().toString());
                editor.putString(Constants.addressNotes," ");
                editor.commit();
                editor.apply();
            }
            StepSingleton.StepOneCompleted = true;
            startActivity(new Intent(AddressActivty.this, LoundryOrderActivity.class));
        }else {
            Toast.makeText(this, "Must provide building and apartment", Toast.LENGTH_SHORT).show();
        }
    }

    private void setSelected(TextView selected) {
        apt.setBackgroundColor(getColor(R.color.white));
        villa.setBackgroundColor(getColor(R.color.white));
        office.setBackgroundColor(getColor(R.color.white));
        hotel.setBackgroundColor(getColor(R.color.white));

        selected.setBackgroundColor(getColor(R.color.selectType));

        editor.putString(Constants.addressType, selected.getText().toString());
        editor.commit();
        editor.apply();
    }
}