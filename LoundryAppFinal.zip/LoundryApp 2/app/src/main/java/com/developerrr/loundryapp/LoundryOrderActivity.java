package com.developerrr.loundryapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.developerrr.loundryapp.adapters.DaysAdapter;
import com.developerrr.loundryapp.adapters.TimesAdapter;
import com.developerrr.loundryapp.constants.Constants;
import com.developerrr.loundryapp.constants.StepSingleton;
import com.developerrr.loundryapp.models.DayModel;
import com.developerrr.loundryapp.models.TimeModel;
import com.google.android.material.bottomsheet.BottomSheetDialog;

import java.util.ArrayList;
import java.util.List;

public class LoundryOrderActivity extends AppCompatActivity implements DaysAdapter.OnCLickListener,TimesAdapter.OnTimeCLickListener{

    CardView addressCard, selectOrderTypeCard, schdulePickUpCard, scheduleDropOffCard;

    RadioButton radioFlex, radioPriority;

    ImageButton addressBtn,orderTypeBtn,pickUpBtn,dropOffBtn,backBtn;
    private CardView continueCard;
    TextView bottomSheetDay,bottomSheetTime;

    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    TextView addressTextView,orderTextV,pickUpTextV,dropOffTextV;
    String selectedDay;

    BottomSheetDialog bottomSheetDropOff;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loundry_order);


        InitializeComponents();


//        if (StepSingleton.StepOneCompleted) {
//            stepOneDone();
//            InitializeStepTwo();
//        }

    }

    private void InitializeStepTwo() {
        selectOrderTypeCard.setOnClickListener(view -> {
            final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(LoundryOrderActivity.this);
            bottomSheetDialog.setContentView(R.layout.bottom_sheet_order_type);

            radioFlex = bottomSheetDialog.findViewById(R.id.radio_flex);
            radioPriority = bottomSheetDialog.findViewById(R.id.radio_priority);
            Button saveOrderBtn=bottomSheetDialog.findViewById(R.id.saveOrderTypeBtn);

            radioFlex.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    radioPriority.setChecked(false);
                    radioFlex.setChecked(true);
                    saveOrderBtn.setText("Select Flex");

                }
            });
            radioPriority.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    radioFlex.setChecked(false);
                    radioPriority.setChecked(true);
                    saveOrderBtn.setText("Select Priority");

                }
            });

            saveOrderBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(saveOrderBtn.getText().toString().equals("Select Priority")){
                        editor.putString(Constants.orderType,"priority");
                        editor.commit();
                        editor.apply();
                        orderTextV.setText("Priority");
                    }else {
                        orderTextV.setText("Flex");

                        editor.putString(Constants.orderType,"flex");
                        editor.commit();
                        editor.apply();
                    }

                    stepTwoDone();
                    bottomSheetDialog.cancel();
                }
            });
            bottomSheetDialog.show();
        });
    }


    private void InitializeComponents() {
        addressCard = findViewById(R.id.addressCard);
        selectOrderTypeCard = findViewById(R.id.selectOrderTYpeCard);

        schdulePickUpCard = findViewById(R.id.schedule_pickUpCard);
        scheduleDropOffCard = findViewById(R.id.schedule_dropoffCard);
        continueCard=findViewById(R.id.bottom_continue_card);

        addressTextView=findViewById(R.id.address_textV);
        orderTextV=findViewById(R.id.order_textV);
        pickUpTextV=findViewById(R.id.pickup_textV);
        dropOffTextV=findViewById(R.id.dropOff_textV);

        addressBtn=findViewById(R.id.address_btn);
        orderTypeBtn=findViewById(R.id.orderType_btn);
        pickUpBtn=findViewById(R.id.pickUp_btn);
        dropOffBtn=findViewById(R.id.dropOff_btn);

        backBtn=findViewById(R.id.laundry_order_backBtn);
        backBtn.setOnClickListener(view -> finish());

        sharedPreferences=getSharedPreferences(Constants.prefsName,MODE_PRIVATE);
        editor=sharedPreferences.edit();

        InitializeStepOne();

        //address prefs
        String type=sharedPreferences.getString(Constants.addressType,"");
        String building=sharedPreferences.getString(Constants.addressBuilding,"");
        String apartment=sharedPreferences.getString(Constants.addressAppartment,"");
        String notes=sharedPreferences.getString(Constants.addressNotes,"");
        if(!TextUtils.isEmpty(building)){
            StepSingleton.StepOneCompleted=true;
            stepOneDone();
            InitializeStepTwo();
        }
        addressTextView.setText(type+","+building+","+apartment+","+notes);

        //order prefs
        String ordertype=sharedPreferences.getString(Constants.orderType,"");
        if(!TextUtils.isEmpty(ordertype)){
            orderTextV.setText(ordertype);
            StepSingleton.StepTwoCompleted=true;
            stepTwoDone();
            InitializeStepThree();
        }

        //pick up prefs
        String pickDay=sharedPreferences.getString(Constants.pickUpdAY,"");
        String fr=sharedPreferences.getString(Constants.pickUpfrom,"");
        String to=sharedPreferences.getString(Constants.pickUpto,"");
        if(!TextUtils.isEmpty(pickDay) && !TextUtils.isEmpty(fr) && !TextUtils.isEmpty(to)){
            stepThreeDone();
            InitializeStepFour();
            pickUpTextV.setText(pickDay+" "+fr+" to "+to);

        }

        //drop off prefs
        String dropDay=sharedPreferences.getString(Constants.dropdAY,"");
        String dfr=sharedPreferences.getString(Constants.dropfrom,"");
        String dto=sharedPreferences.getString(Constants.dropto,"");
        if(!TextUtils.isEmpty(dropDay) && !TextUtils.isEmpty(dfr) && !TextUtils.isEmpty(dto)){
            stepFourDone();
            dropOffTextV.setText(pickDay+" "+fr+" to "+to);
        }

    }

    private void InitializeStepOne() {
        selectOrderTypeCard.setCardElevation(0);
        schdulePickUpCard.setCardElevation(0);
        scheduleDropOffCard.setCardElevation(0);

        addressCard.setBackgroundResource(R.drawable.card_bg);

        addressCard.setOnClickListener(view -> startActivity(new Intent(LoundryOrderActivity.this, MapActivity.class)));
    }

    private void stepOneDone() {
        selectOrderTypeCard.setCardElevation(6);
        selectOrderTypeCard.setBackgroundResource(R.drawable.card_bg);
        addressCard.setBackgroundResource(0);
        addressBtn.setImageResource(R.drawable.ic_edit);

        InitializeStepTwo();
    }
    private void stepTwoDone() {

        orderTypeBtn.setImageResource(R.drawable.ic_edit);
        selectOrderTypeCard.setCardElevation(6);
        selectOrderTypeCard.setBackgroundResource(0);


        InitializeStepThree();

    }

    private void InitializeStepThree() {
        schdulePickUpCard.setBackgroundResource(R.drawable.card_bg);
        Log.d("TAG", "stepThreeDone: PickUp");

        schdulePickUpCard.setOnClickListener(view2 -> {
            final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(LoundryOrderActivity.this);
            bottomSheetDialog.setContentView(R.layout.bottom_sheet_pick_up);

            RecyclerView daysReycler = bottomSheetDialog.findViewById(R.id.days_reycler);
            RecyclerView timesReycler = bottomSheetDialog.findViewById(R.id.times_reycler);
            TextView doneBtn=bottomSheetDialog.findViewById(R.id.done_bottomsheet);
            bottomSheetDay=bottomSheetDialog.findViewById(R.id.bottom_sheet_day);
            bottomSheetTime=bottomSheetDialog.findViewById(R.id.bottom_sheet_time);

            bottomSheetDay.setText(getDays().get(0).getDay());
            bottomSheetTime.setText(getTimes().get(0).getFrom()+" to "+getTimes().get(0).getTo());

            daysReycler.setLayoutManager(new LinearLayoutManager(LoundryOrderActivity.this));
            timesReycler.setLayoutManager(new LinearLayoutManager(LoundryOrderActivity.this));

            List<DayModel> days = getDays();
            List<TimeModel> times = getTimes();

            DaysAdapter daysAdapter = new DaysAdapter(days, this, this);
            TimesAdapter timesAdapter = new TimesAdapter(this, times, this);

            daysReycler.setAdapter(daysAdapter);
            timesReycler.setAdapter(timesAdapter);

            doneBtn.setOnClickListener(view3 ->{

                stepThreeDone();
                InitializeStepFour();
                bottomSheetDialog.cancel();
            });


            bottomSheetDialog.show();
        });
    }

    private void stepThreeDone() {

        pickUpBtn.setImageResource(R.drawable.ic_edit);

        schdulePickUpCard.setBackgroundResource(0);
        schdulePickUpCard.setCardElevation(6);
        scheduleDropOffCard.setBackgroundResource(R.drawable.card_bg);
        schdulePickUpCard.setBackgroundResource(0);
        Log.d("TAG", "stepThreeDone: DropOff");
    }
    private void stepFourDone() {
        StepSingleton.StepFourCompleted=true;

        dropOffBtn.setImageResource(R.drawable.ic_edit);


        scheduleDropOffCard.setBackgroundResource(0);
        scheduleDropOffCard.setCardElevation(6);
        continueCard.setBackgroundColor(getColor(R.color.light_blue));

        continueCard.setOnClickListener(view -> startActivity(new Intent(LoundryOrderActivity.this,InstructionsActivity.class)));
    }


    private void InitializeStepFour() {


        scheduleDropOffCard.setOnClickListener(view4 ->{
            bottomSheetDropOff= new BottomSheetDialog(LoundryOrderActivity.this);
            bottomSheetDropOff.setContentView(R.layout.bottom_sheet_drop_off);

            RecyclerView daysReycler1 = bottomSheetDropOff.findViewById(R.id.drop_days_reycler);
            RecyclerView timesReycler1 = bottomSheetDropOff.findViewById(R.id.drop_times_reycler);
            TextView doneBtn1=bottomSheetDropOff.findViewById(R.id.dropOff_done);

            bottomSheetDay=bottomSheetDropOff.findViewById(R.id.dropOff_sheet_day);
            bottomSheetTime=bottomSheetDropOff.findViewById(R.id.dropOff_sheet_time);

            bottomSheetDay.setText(getDays().get(0).getDay());
            bottomSheetTime.setText(getTimes().get(0).getFrom()+" to "+getTimes().get(0).getTo());

            daysReycler1.setLayoutManager(new LinearLayoutManager(LoundryOrderActivity.this));
            timesReycler1.setLayoutManager(new LinearLayoutManager(LoundryOrderActivity.this));

            List<DayModel> days1 = getDays();
            List<TimeModel> times1= getTimes();

            DaysAdapter daysAdapter1 = new DaysAdapter(days1, this,this::OnItemCLick);
            TimesAdapter timesAdapter1 = new TimesAdapter(this, times1,this::OnTimeItemCLick);

            daysReycler1.setAdapter(daysAdapter1);
            timesReycler1.setAdapter(timesAdapter1);

            doneBtn1.setOnClickListener(view -> {
                stepFourDone();
                bottomSheetDropOff.cancel();

            });
            bottomSheetDropOff.show();
        });

    }





    private List<DayModel> getDays() {
        List<DayModel> dayModels=new ArrayList<>();

        dayModels.add(new DayModel("Monday","May 11"));
        dayModels.add(new DayModel("Tuesday","May 12"));
        dayModels.add(new DayModel("Wednesday","May 13"));
        dayModels.add(new DayModel("Thursday","May 14"));
        dayModels.add(new DayModel("Friday","May 15"));
        dayModels.add(new DayModel("Saturday","May 16"));
        dayModels.add(new DayModel("Sunday","May 17"));


        return dayModels;
    }

    private List<TimeModel> getTimes() {
        List<TimeModel> timeModels=new ArrayList<>();

        timeModels.add(new TimeModel("Between","12:00 pm","01:00 pm"));
        timeModels.add(new TimeModel("Between","1:00 pm","02:00 pm"));
        timeModels.add(new TimeModel("Between","2:00 pm","03:00 pm"));
        timeModels.add(new TimeModel("Between","11:00 am","12:00 pm"));
        timeModels.add(new TimeModel("Between","10:00 am","11:00 am"));
        timeModels.add(new TimeModel("Between","12:00 pm","01:00 pm"));
        timeModels.add(new TimeModel("Between","04:00 pm","05:00 pm"));


        return timeModels;
    }

    @Override
    public void OnItemCLick(int position) {
        if(bottomSheetDropOff!=null && bottomSheetDropOff.isShowing()){
            selectedDay = getDays().get(position).getDay();
            bottomSheetDay.setText(getDays().get(position).getDay());
            editor.putString(Constants.dropdAY, getDays().get(position).getDay());
            editor.commit();
            editor.apply();

            String fr = sharedPreferences.getString(Constants.dropfrom, "");
            String t = sharedPreferences.getString(Constants.dropto, "");
            dropOffTextV.setText(getDays().get(position).getDay() + "," + fr + " to " + t);
        }else {
            selectedDay = getDays().get(position).getDay();
            bottomSheetDay.setText(getDays().get(position).getDay());
            editor.putString(Constants.pickUpdAY, getDays().get(position).getDay());
            editor.commit();
            editor.apply();

            String fr = sharedPreferences.getString(Constants.pickUpfrom, "");
            String t = sharedPreferences.getString(Constants.pickUpto, "");
            pickUpTextV.setText(getDays().get(position).getDay() + "," + fr + " to " + t);
        }

    }
    @Override
    public void OnTimeItemCLick(int position) {
        if(bottomSheetDropOff!=null && bottomSheetDropOff.isShowing()){
            TimeModel time = getTimes().get(position);
            bottomSheetTime.setText(time.getFrom() + " to " + time.getTo());

            editor.putString(Constants.dropfrom, time.getFrom());
            editor.putString(Constants.dropto, time.getTo());
            editor.commit();
            editor.apply();

            selectedDay = sharedPreferences.getString(Constants.dropdAY, "");
            dropOffTextV.setText(selectedDay + ", " + time.getFrom() + " to " + time.getTo());

        }else {
            TimeModel time = getTimes().get(position);
            bottomSheetTime.setText(time.getFrom() + " to " + time.getTo());

            editor.putString(Constants.pickUpfrom, time.getFrom());
            editor.putString(Constants.pickUpto, time.getTo());
            editor.commit();
            editor.apply();

            selectedDay = sharedPreferences.getString(Constants.pickUpdAY, "");
            pickUpTextV.setText(selectedDay + ", " + time.getFrom() + " to " + time.getTo());
        }

    }
}