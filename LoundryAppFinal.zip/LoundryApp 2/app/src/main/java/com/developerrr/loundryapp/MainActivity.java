package com.developerrr.loundryapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.developerrr.loundryapp.adapters.DaysAdapter;
import com.developerrr.loundryapp.adapters.TimesAdapter;
import com.developerrr.loundryapp.interfaces.RecyclerListeners;
import com.developerrr.loundryapp.models.DayModel;
import com.developerrr.loundryapp.models.TimeModel;
import com.google.android.material.bottomsheet.BottomSheetDialog;

import org.imaginativeworld.whynotimagecarousel.ImageCarousel;
import org.imaginativeworld.whynotimagecarousel.model.CarouselItem;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class MainActivity extends AppCompatActivity{

    ImageButton emailBtn,dollarBtn,menuBtn;
    RelativeLayout placeNewOrderBtn;
    CardView pricingCard;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        InitializeComponents();

        // Java
        ImageCarousel carousel = findViewById(R.id.carousel);
        carousel.registerLifecycle(getLifecycle());

        List<CarouselItem> list = new ArrayList<>();

        list.add(
                new CarouselItem(
                        R.drawable.adimage
                )
        );

        list.add(
                new CarouselItem(
                        R.drawable.adimage1
                )
        );
        list.add(
                new CarouselItem(
                        R.drawable.adimage2
                )
        );

        carousel.setData(list);

    }

    private void InitializeComponents() {
        emailBtn=findViewById(R.id.email_btn);
        dollarBtn=findViewById(R.id.dollar_btn);
        menuBtn=findViewById(R.id.menu_Btn);
        placeNewOrderBtn=findViewById(R.id.placeNewOrderLayout);
        pricingCard=findViewById(R.id.pricing_Card);

        pricingCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this,PricingActivity.class));
            }
        });


        emailBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showEmailSheetDialog();
            }
        });

        dollarBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showPricingSheetDialog();
            }
        });

        menuBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this,ProfileActivity.class));
            }
        });

        placeNewOrderBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this,LoundryOrderActivity.class));
            }
        });
    }


    private void showEmailSheetDialog() {

        final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this);
        bottomSheetDialog.setContentView(R.layout.bottom_sheet_email);

        bottomSheetDialog.show();
    }

    private void showPricingSheetDialog() {

        final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this);
        bottomSheetDialog.setContentView(R.layout.bottom_sheet_pricing);

        bottomSheetDialog.show();
    }


}