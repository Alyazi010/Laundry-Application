package com.developerrr.loundryapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.developerrr.loundryapp.adapters.DaysAdapter;
import com.developerrr.loundryapp.adapters.ExpandableListAdapter;
import com.developerrr.loundryapp.adapters.TimesAdapter;
import com.developerrr.loundryapp.models.DayModel;
import com.developerrr.loundryapp.models.ExpandableItem;
import com.developerrr.loundryapp.models.TimeModel;
import com.google.android.material.bottomsheet.BottomSheetDialog;

import net.cachapa.expandablelayout.ExpandableLayout;

import java.util.ArrayList;
import java.util.List;

public class InstructionsActivity extends AppCompatActivity implements View.OnClickListener {

    ImageButton backBtn,lApprovalsImageBtn,extraBagsImageBtn;
    TextView instructionTv;
    boolean continueEnabled=false;

    CardView laundryInstruction,lapprovalsCard,driverInstrucations,extraBags,continuCard;

    BottomSheetDialog instructionsSheet;
    private String instructionText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_instructions);

        backBtn=findViewById(R.id.instructions_backBtn);
        laundryInstruction=findViewById(R.id.loundry_instruction_card);
        lapprovalsCard=findViewById(R.id.laundry_approvals_card);
        driverInstrucations=findViewById(R.id.driver_instructions_card);
        extraBags=findViewById(R.id.need_extra_bags_card);
        instructionTv=findViewById(R.id.laundry_instructions_textview);
        lApprovalsImageBtn=findViewById(R.id.laundry_approvals_ImageBtn);
        extraBagsImageBtn=findViewById(R.id.extrabags_ImageBtn);
        continuCard=findViewById(R.id.instructions_continue_card);

        laundryInstruction.setOnClickListener(this);
        lapprovalsCard.setOnClickListener(this);
        driverInstrucations.setOnClickListener(this);
        extraBags.setOnClickListener(this);
        continuCard.setOnClickListener(this);

        backBtn.setOnClickListener(view -> finish());
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.loundry_instruction_card:
                createInstructionSheet();
                break;
            case R.id.laundry_approvals_card:
                lApprovalsImageBtn.setImageResource(R.drawable.ic_check);
                break;
            case R.id.driver_instructions_card:
                createDriverInstructionsSheet();
                break;
            case R.id.need_extra_bags_card:
                extraBagsImageBtn.setImageResource(R.drawable.ic_check);
                continuCard.setBackgroundColor(getColor(R.color.light_blue));
                continueEnabled=true;
                break;
            case R.id.folding_card:
                createFoldingSheet();
                break;
            case R.id.creases_card:
                createCreasesSheet();
                break;
            case R.id.starch_card:
                createStarcSheet();
                break;
            case R.id.instructions_continue_card:
                if(continueEnabled) {
                    startActivity(new Intent(InstructionsActivity.this, PaymentActivity.class));
                }
                break;
        }
    }

    private void createDriverInstructionsSheet() {
        BottomSheetDialog driverSheet=new BottomSheetDialog(InstructionsActivity.this);
        driverSheet.setContentView(R.layout.bottom_sheet_driver_instructions);

        ImageButton closeBtn=driverSheet.findViewById(R.id.driver_sheet_closeBtn);
        closeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                driverSheet.cancel();
            }
        });

        RelativeLayout ring=driverSheet.findViewById(R.id.btn_ringDoor);
        RelativeLayout knock=driverSheet.findViewById(R.id.btn_knockDoor);
        RelativeLayout dontDisturb=driverSheet.findViewById(R.id.btn_dontDisturb);

        ImageButton ringBtn=driverSheet.findViewById(R.id.ringDoor_check);
        ImageButton knockBtn=driverSheet.findViewById(R.id.knockDoor_check);
        ImageButton dontDisturbBtn=driverSheet.findViewById(R.id.dontDisturb_check);

        ring.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ringBtn.setVisibility(View.VISIBLE);
                knockBtn.setVisibility(View.INVISIBLE);
                dontDisturbBtn.setVisibility(View.INVISIBLE);
            }
        });

        knock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ringBtn.setVisibility(View.INVISIBLE);
                knockBtn.setVisibility(View.VISIBLE);
                dontDisturbBtn.setVisibility(View.INVISIBLE);
            }
        });

        dontDisturb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ringBtn.setVisibility(View.INVISIBLE);
                knockBtn.setVisibility(View.INVISIBLE);
                dontDisturbBtn.setVisibility(View.VISIBLE);
            }
        });



        driverSheet.show();


    }

    private void createFoldingSheet() {

        instructionText="Folding: ";

        BottomSheetDialog foldingSheet= new BottomSheetDialog(InstructionsActivity.this);
        foldingSheet.setContentView(R.layout.bottom_sheet_folding);

        RelativeLayout btnTops,btnBottoms,btnHouseItems,btnFormals,btnOthers;

        ImageButton closeBtn=foldingSheet.findViewById(R.id.folding_sheet_closeBtn);
        closeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                foldingSheet.cancel();
            }
        });

        btnBottoms=foldingSheet.findViewById(R.id.btn_bottoms);
        btnTops=foldingSheet.findViewById(R.id.btn_tops);
        btnHouseItems=foldingSheet.findViewById(R.id.btn_housItems);
        btnFormals=foldingSheet.findViewById(R.id.btn_formal);
        btnOthers=foldingSheet.findViewById(R.id.btn_others);

        ExpandableLayout topsLayout=foldingSheet.findViewById(R.id.folding_layout_top);
        ExpandableLayout bottomsLayout=foldingSheet.findViewById(R.id.folding_layout_bottoms);
        ExpandableLayout houseItemsLayout=foldingSheet.findViewById(R.id.folding_layout_houseitems);
        ExpandableLayout formalsLayout=foldingSheet.findViewById(R.id.folding_layout_formal);
        ExpandableLayout otherLayout=foldingSheet.findViewById(R.id.folding_layout_others);


        setUpListViews(foldingSheet);


        btnBottoms.setOnClickListener(view -> setLayout(bottomsLayout));
        btnTops.setOnClickListener(view -> setLayout(topsLayout));
        btnHouseItems.setOnClickListener(view -> setLayout(houseItemsLayout));
        btnFormals.setOnClickListener(view -> setLayout(formalsLayout));
        btnOthers.setOnClickListener(view -> setLayout(otherLayout));


        foldingSheet.show();

    }

    private void setUpListViews(BottomSheetDialog foldingSheet) {
        ListView listView_tops=foldingSheet.findViewById(R.id.listView_tops);
        ListView listView_bottoms=foldingSheet.findViewById(R.id.listView_bottoms);
        ListView listView_housItems=foldingSheet.findViewById(R.id.listView_houseItems);
        ListView listView_formals=foldingSheet.findViewById(R.id.listView_formals);
        ListView listView_others=foldingSheet.findViewById(R.id.listView_others);

        ExpandableListAdapter adapter=new ExpandableListAdapter(getTops(),this);
        listView_tops.setAdapter(adapter);

        ExpandableListAdapter adapterBottoms=new ExpandableListAdapter(getBottoms(),this);
        listView_bottoms.setAdapter(adapterBottoms);

        ExpandableListAdapter adapterHouseItems=new ExpandableListAdapter(getHouseItems(),this);
        listView_housItems.setAdapter(adapterHouseItems);

        ExpandableListAdapter adapterFormals=new ExpandableListAdapter(getFormals(),this);
        listView_formals.setAdapter(adapterFormals);

        ExpandableListAdapter adapterOthers=new ExpandableListAdapter(getOthers(),this);
        listView_others.setAdapter(adapterOthers);


        listView_tops.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                ImageButton btn=view.findViewById(R.id.item_imageButton);
                btn.setImageResource(R.drawable.ic_check);
                instructionText+=getTops().get(i).getName()+" ,";
                instructionTv.setText(instructionText);
                instructionTv.setVisibility(View.VISIBLE);
            }
        });


        listView_bottoms.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                ImageButton btn=view.findViewById(R.id.item_imageButton);
                btn.setImageResource(R.drawable.ic_check);
                instructionText+=getBottoms().get(i).getName()+" ,";
                instructionTv.setText(instructionText);
                instructionTv.setVisibility(View.VISIBLE);
            }
        });

        listView_housItems.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                ImageButton btn=view.findViewById(R.id.item_imageButton);
                btn.setImageResource(R.drawable.ic_check);
                instructionText+=getHouseItems().get(i).getName()+" ,";
                instructionTv.setText(instructionText);
                instructionTv.setVisibility(View.VISIBLE);
            }
        });

        listView_formals.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                ImageButton btn=view.findViewById(R.id.item_imageButton);
                btn.setImageResource(R.drawable.ic_check);
                instructionText+=getFormals().get(i).getName()+" ,";
                instructionTv.setText(instructionText);
                instructionTv.setVisibility(View.VISIBLE);
            }
        });

        listView_others.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                ImageButton btn=view.findViewById(R.id.item_imageButton);
                btn.setImageResource(R.drawable.ic_check);
                instructionText+=getOthers().get(i).getName()+" ,";
                instructionTv.setText(instructionText);
                instructionTv.setVisibility(View.VISIBLE);
            }
        });
    }

    private List<ExpandableItem> getOthers() {
        List<ExpandableItem> tops=new ArrayList<>();
        tops.add(new ExpandableItem("SomeClothes"));
        tops.add(new ExpandableItem("OthersClothes"));
        tops.add(new ExpandableItem("ClothItems"));

        return tops;
    }
    private List<ExpandableItem> getFormals() {
        List<ExpandableItem> tops=new ArrayList<>();
        tops.add(new ExpandableItem("Coat"));
        tops.add(new ExpandableItem("Waistcoat"));
        tops.add(new ExpandableItem("Tie"));
        tops.add(new ExpandableItem("Formal Dress"));

        return tops;
    }
    private List<ExpandableItem> getHouseItems() {
        List<ExpandableItem> tops=new ArrayList<>();
        tops.add(new ExpandableItem("Bad sheets"));
        tops.add(new ExpandableItem("Pillows"));
        tops.add(new ExpandableItem("Blanket"));
        tops.add(new ExpandableItem("Curtains"));

        return tops;
    }
    private List<ExpandableItem> getBottoms() {
        List<ExpandableItem> tops=new ArrayList<>();
        tops.add(new ExpandableItem("Shorts"));
        tops.add(new ExpandableItem("Pants"));
        tops.add(new ExpandableItem("Skirts"));
        tops.add(new ExpandableItem("Jeans"));

        return tops;
    }
    private List<ExpandableItem> getTops() {
        List<ExpandableItem> tops=new ArrayList<>();
        tops.add(new ExpandableItem("Shirts"));
        tops.add(new ExpandableItem("T Shirts"));
        tops.add(new ExpandableItem("Blouse"));

        return tops;
    }

    private void setLayout(ExpandableLayout layout) {
        if(layout.isExpanded()) {
            layout.collapse();
        } else {
            layout.expand();
        }
    }

    private void createCreasesSheet() {
        instructionText+="\nCreases: ";

        BottomSheetDialog creaseSheet= new BottomSheetDialog(InstructionsActivity.this);
        creaseSheet.setContentView(R.layout.bottom_sheet_crease);

        RelativeLayout shirt,pant,kandura,gathra;

        ImageButton closeBtn=creaseSheet.findViewById(R.id.crease_sheet_closeBtn);
        closeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                creaseSheet.cancel();
            }
        });

        shirt=creaseSheet.findViewById(R.id.btn_shirt);
        pant=creaseSheet.findViewById(R.id.btn_pant);
        kandura=creaseSheet.findViewById(R.id.btn_kahdhura);
        gathra=creaseSheet.findViewById(R.id.btn_gathra);


        ExpandableLayout shirtLayout=creaseSheet.findViewById(R.id.crease_layout_shirt);
        ExpandableLayout pantLayout=creaseSheet.findViewById(R.id.crease_layout_pant);
        ExpandableLayout kanduraLayout=creaseSheet.findViewById(R.id.crease_layout_kandhura);
        ExpandableLayout gathraLayout=creaseSheet.findViewById(R.id.crease_layout_gathra);


        ListView listView_shirt=creaseSheet.findViewById(R.id.listView_shirt);
        ListView listView_pant=creaseSheet.findViewById(R.id.listView_pants);
        ListView listView_kandura=creaseSheet.findViewById(R.id.listView_kandhura);
        ListView listView_gathra=creaseSheet.findViewById(R.id.listView_gathra);

        ExpandableListAdapter adapter=new ExpandableListAdapter(getTops(),this);
        listView_shirt.setAdapter(adapter);

        ExpandableListAdapter adapterBottoms=new ExpandableListAdapter(getTops(),this);
        listView_pant.setAdapter(adapterBottoms);

        ExpandableListAdapter adapterHouseItems=new ExpandableListAdapter(getTops(),this);
        listView_kandura.setAdapter(adapterHouseItems);

        ExpandableListAdapter adapterFormals=new ExpandableListAdapter(getTops(),this);
        listView_gathra.setAdapter(adapterFormals);


        listView_shirt.setOnItemClickListener((adapterView, view, i, l) -> {
            ImageButton btn=view.findViewById(R.id.item_imageButton);
            btn.setImageResource(R.drawable.ic_check);

            instructionText+=getTops().get(i).getName()+" ,";
            instructionTv.setText(instructionText);
            instructionTv.setVisibility(View.VISIBLE);
        });

        shirt.setOnClickListener(view -> setLayout(shirtLayout));
        pant.setOnClickListener(view -> setLayout(pantLayout));
        kandura.setOnClickListener(view -> setLayout(kanduraLayout));
        gathra.setOnClickListener(view -> setLayout(gathraLayout));


        creaseSheet.show();

    }

    private void createStarcSheet() {

        instructionText+="\nStarch: ";

        BottomSheetDialog starchSheet=new BottomSheetDialog(InstructionsActivity.this);
        starchSheet.setContentView(R.layout.bottom_sheet_starch);

        ImageButton closeBtn=starchSheet.findViewById(R.id.starc_sheet_closeBtn);
        closeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                starchSheet.cancel();
            }
        });

        RelativeLayout none=starchSheet.findViewById(R.id.btn_starch_none);
        RelativeLayout light=starchSheet.findViewById(R.id.btn_starch_light);
        RelativeLayout medium=starchSheet.findViewById(R.id.btn_starch_medium);
        RelativeLayout hard=starchSheet.findViewById(R.id.btn_starch_hard);

        ImageButton noneBtn=starchSheet.findViewById(R.id.none_check);
        ImageButton lightBtn=starchSheet.findViewById(R.id.light_check);
        ImageButton mediumBtn=starchSheet.findViewById(R.id.medium_check);
        ImageButton hardBtn=starchSheet.findViewById(R.id.hard_check);

        none.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                noneBtn.setVisibility(View.VISIBLE);
                lightBtn.setVisibility(View.INVISIBLE);
                mediumBtn.setVisibility(View.INVISIBLE);
                hardBtn.setVisibility(View.INVISIBLE);


            }
        });

        light.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                noneBtn.setVisibility(View.INVISIBLE);
                lightBtn.setVisibility(View.VISIBLE);
                mediumBtn.setVisibility(View.INVISIBLE);
                hardBtn.setVisibility(View.INVISIBLE);

                instructionText+="Light Starch Shirts";
                instructionTv.setText(instructionText);
                instructionTv.setVisibility(View.VISIBLE);

            }
        });

        medium.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                noneBtn.setVisibility(View.INVISIBLE);
                lightBtn.setVisibility(View.INVISIBLE);
                mediumBtn.setVisibility(View.VISIBLE);
                hardBtn.setVisibility(View.INVISIBLE);

                instructionText+="Medium Starch Shirts";
                instructionTv.setText(instructionText);
                instructionTv.setVisibility(View.VISIBLE);

            }
        });

        hard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                noneBtn.setVisibility(View.INVISIBLE);
                lightBtn.setVisibility(View.INVISIBLE);
                mediumBtn.setVisibility(View.INVISIBLE);
                hardBtn.setVisibility(View.VISIBLE);

                instructionText+="Hard Starch Shirts";
                instructionTv.setText(instructionText);
                instructionTv.setVisibility(View.VISIBLE);

            }
        });

        starchSheet.show();

    }

    private void createInstructionSheet() {
        instructionsSheet= new BottomSheetDialog(InstructionsActivity.this);
        instructionsSheet.setContentView(R.layout.bottom_sheet_instructions);

        ImageButton closeBtn=instructionsSheet.findViewById(R.id.instructions_sheet_closeBtn);


        CardView folding=instructionsSheet.findViewById(R.id.folding_card);
        CardView creases=instructionsSheet.findViewById(R.id.creases_card);
        CardView starch=instructionsSheet.findViewById(R.id.starch_card);

        folding.setOnClickListener(this);
        creases.setOnClickListener(this);
        starch.setOnClickListener(this);



        closeBtn.setOnClickListener(view -> {
            instructionsSheet.cancel();

        });
        instructionsSheet.show();
    }
}