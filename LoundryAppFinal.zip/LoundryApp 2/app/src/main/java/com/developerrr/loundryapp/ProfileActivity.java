package com.developerrr.loundryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class ProfileActivity extends AppCompatActivity {

    ImageButton emailBtn,dollarBtn,backBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);


        emailBtn=findViewById(R.id.email_btn_profile);
        dollarBtn=findViewById(R.id.dollar_btn_profile);
        backBtn=findViewById(R.id.arrowBack_Btn);

        emailBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //showEmailSheetDialog();
            }
        });

        dollarBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //showPricingSheetDialog();
            }
        });

        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

    }
}