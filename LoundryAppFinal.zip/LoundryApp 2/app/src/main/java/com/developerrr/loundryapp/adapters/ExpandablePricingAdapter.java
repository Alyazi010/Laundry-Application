package com.developerrr.loundryapp.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.developerrr.loundryapp.R;
import com.developerrr.loundryapp.models.ExpandableItem;
import com.developerrr.loundryapp.models.PricingModel;

import java.util.List;
// this list for the prcies to expand when we click the
public class ExpandablePricingAdapter extends BaseAdapter {
    List<PricingModel> items;
    Context context;

    public ExpandablePricingAdapter(List<PricingModel> items, Context context) {
        this.items = items;
        this.context = context;
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public Object getItem(int i) {
        return items.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        if(view==null) {
            view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.expandable_pricing_listview_item, viewGroup, false);
        }
        TextView name=view.findViewById(R.id.pricing_itemName);
        TextView price=view.findViewById(R.id.pricing_item_price);

        name.setText(items.get(i).getName());
        price.setText(items.get(i).getPrice());

        return view;
    }
}
