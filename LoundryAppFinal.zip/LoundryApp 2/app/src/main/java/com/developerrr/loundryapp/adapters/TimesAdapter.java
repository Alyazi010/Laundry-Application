package com.developerrr.loundryapp.adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.developerrr.loundryapp.R;
import com.developerrr.loundryapp.models.TimeModel;

import java.util.List;
// this code is for picktime
public class TimesAdapter extends RecyclerView.Adapter<TimesAdapter.TimesViewHolder>{

    Context context;
    List<TimeModel> times;
    private int row_index;
    TimesAdapter.OnTimeCLickListener timeListeners;

    public interface OnTimeCLickListener{
        void OnTimeItemCLick(int position);
    }

    public TimesAdapter(Context context, List<TimeModel> times, TimesAdapter.OnTimeCLickListener onCLickListener) {
        this.context = context;
        this.times = times;
        this.timeListeners=onCLickListener;
    }

    @NonNull
    @Override
    public TimesViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.single_time_item,parent,false);

        return new TimesViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TimesViewHolder holder, @SuppressLint("RecyclerView") int position) {

        TimeModel time=times.get(position);

        holder.between.setText(time.getTextBtw());
        holder.from.setText(time.getFrom());
        holder.to.setText(time.getTo());

        holder.rootCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                row_index=position;
                notifyDataSetChanged();
                timeListeners.OnTimeItemCLick(position);
            }
        });

        if(row_index==position){
            holder.rootCard.setCardBackgroundColor(context.getColor(R.color.selectType));
        }
        else
        {
            holder.rootCard.setCardBackgroundColor(context.getColor(R.color.light_white));
        }
    }

    @Override
    public int getItemCount() {
        return times.size();
    }

    class TimesViewHolder extends RecyclerView.ViewHolder{

        TextView between;
        TextView from;
        TextView to;
        CardView rootCard;

        public TimesViewHolder(@NonNull View itemView) {
            super(itemView);

            between=itemView.findViewById(R.id.time_between);
            from=itemView.findViewById(R.id.time_from);
            to=itemView.findViewById(R.id.time_to);
            rootCard=itemView.findViewById(R.id.rootCardLayout);
        }
    }
}
