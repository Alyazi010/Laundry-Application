package com.developerrr.loundryapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.developerrr.loundryapp.constants.Constants;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class MapActivity extends FragmentActivity implements OnMapReadyCallback{

    GoogleMap mMap;
    LinearLayout confirmPin;
    EditText searchField;
    LatLng selectedPos;

    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);
        confirmPin=findViewById(R.id.confirmLocation);
        searchField=findViewById(R.id.map_edittext);

        sharedPreferences=getSharedPreferences(Constants.prefsName,MODE_PRIVATE);
        editor=sharedPreferences.edit();

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        confirmPin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(selectedPos!=null){
                    startActivity(new Intent(MapActivity.this,AddressActivty.class));
                    finish();
                }else {
                    Toast.makeText(MapActivity.this, "Select Location First", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;

        LatLng dubai=new LatLng(25.2048,55.2708);

        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(dubai,12));

        mMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
            @Override
            public void onMapClick(@NonNull LatLng latLng) {
                selectedPos=latLng;

                editor.putLong(Constants.latitude, (long) latLng.latitude);
                editor.putLong(Constants.longitude, (long) latLng.latitude);
                editor.commit();
                editor.apply();

                mMap.addMarker(new
                        MarkerOptions().position(latLng).title("Selected Location"));
            }
        });


    }
}