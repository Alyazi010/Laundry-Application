package com.developerrr.loundryapp;




import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.RelativeLayout;

import com.developerrr.loundryapp.adapters.ExpandablePricingAdapter;
import com.developerrr.loundryapp.models.ExpandableItem;
import com.developerrr.loundryapp.models.PricingModel;

import net.cachapa.expandablelayout.ExpandableLayout;

import java.util.ArrayList;
import java.util.List;


public class PricingActivity extends AppCompatActivity implements View.OnClickListener {


    ImageButton backBtn;
    RelativeLayout tops,bottoms,undergarments,houseItems,formal,others;

    ExpandableLayout topsLayout,bottomsLayout,otherLayout;
    ListView listViewTopsLayout,listViewBottomsLayout,listViewOtherLayout;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pricing);


        InitializeComponents();

        ExpandablePricingAdapter adapter=new ExpandablePricingAdapter(getTops(),this);
        listViewTopsLayout.setAdapter(adapter);

        ExpandablePricingAdapter adapterbotom=new ExpandablePricingAdapter(getBottoms(),this);
        listViewBottomsLayout.setAdapter(adapterbotom);

        ExpandablePricingAdapter adapterothers=new ExpandablePricingAdapter(getOthers(),this);
        listViewOtherLayout.setAdapter(adapterothers);


    }
    private List<PricingModel> getTops() {
        List<PricingModel> tops=new ArrayList<>();
        tops.add(new PricingModel("Shirts","AED 15"));
        tops.add(new PricingModel("T Shirts","AED 13"));
        tops.add(new PricingModel("Blouse","AED 8"));

        return tops;
    }

    private List<PricingModel> getBottoms() {
        List<PricingModel> bot=new ArrayList<>();
        bot.add(new PricingModel("Jeans","AED 20"));
        bot.add(new PricingModel("Pants","AED 25"));
        bot.add(new PricingModel("Shorts","AED 15"));
        bot.add(new PricingModel("Underwear","AED 10"));

        return bot;
    }

    private List<PricingModel> getOthers() {
        List<PricingModel> oth=new ArrayList<>();
        oth.add(new PricingModel("Bed Cover","AED 50"));
        oth.add(new PricingModel("Towel","AED 15"));
        oth.add(new PricingModel("Pillow","AED 15"));

        return oth;
    }

    private void InitializeComponents() {
        backBtn=findViewById(R.id.pricing_backBtn);
        tops=findViewById(R.id.pricing_tops);
        bottoms=findViewById(R.id.pricing_bottoms);
        others=findViewById(R.id.pricing_others);

        topsLayout=findViewById(R.id.pricing_layout_top);
        bottomsLayout=findViewById(R.id.pricing_layout_bottoms);
        otherLayout=findViewById(R.id.pricing_layout_others);

        listViewTopsLayout=findViewById(R.id.pricing_listView_tops);
        listViewBottomsLayout=findViewById(R.id.pricing_listView_bottoms);
        listViewOtherLayout=findViewById(R.id.pricing_listView_others);

        backBtn.setOnClickListener(this);
        tops.setOnClickListener(this);
        bottoms.setOnClickListener(this);
        others.setOnClickListener(this);
    }

    private void setLayout(ExpandableLayout layout) {
        if(layout.isExpanded()) {
            layout.collapse();
        } else {
            layout.expand();
        }
    }
    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.pricing_backBtn:
                finish();
                break;
            case R.id.pricing_tops:
                setLayout(topsLayout);
                break;
            case R.id.pricing_bottoms:
                setLayout(bottomsLayout);
                break;
            case R.id.pricing_others:
                setLayout(otherLayout);
                break;
        }
    }
}