package com.developerrr.loundryapp.models;

public class TimeModel {
    String textBtw;
    String from;
    String to;

    public TimeModel(String textBtw, String from, String to) {
        this.textBtw = textBtw;
        this.from = from;
        this.to = to;
    }

    public String getTextBtw() {
        return textBtw;
    }

    public void setTextBtw(String textBtw) {
        this.textBtw = textBtw;
    }

    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public String getTo() {
        return to;
    }

    public void setTo(String to) {
        this.to = to;
    }
}
