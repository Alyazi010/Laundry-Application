package com.developerrr.loundryapp.adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.developerrr.loundryapp.R;
import com.developerrr.loundryapp.interfaces.RecyclerListeners;
import com.developerrr.loundryapp.models.DayModel;

import java.util.List;

public class DaysAdapter extends RecyclerView.Adapter<DaysAdapter.DaysViewHolder> {

    List<DayModel> days;
    Context context;
    private int row_index;
    OnCLickListener recyclerListeners;

    public interface OnCLickListener{
        void OnItemCLick(int position);
    }

    public DaysAdapter(List<DayModel> days, Context context,OnCLickListener recyclerListeners) {
        this.days = days;
        this.context = context;
        this.recyclerListeners=recyclerListeners;
    }

    @NonNull
    @Override
    public DaysViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.single_day_item,parent,false);

        return new DaysViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DaysViewHolder holder, @SuppressLint("RecyclerView") int position) {

        DayModel day=days.get(position);

        holder.day.setText(day.getDay());
        holder.date.setText(day.getDate());

        holder.rootCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                row_index=position;
                notifyDataSetChanged();
                recyclerListeners.OnItemCLick(position);
            }
        });

        if(row_index==position){
            holder.rootCard.setCardBackgroundColor(context.getColor(R.color.selectType));
        }
        else
        {
            holder.rootCard.setCardBackgroundColor(context.getColor(R.color.light_white));
        }
    }

    @Override
    public int getItemCount() {
        return days.size();
    }

    class DaysViewHolder extends RecyclerView.ViewHolder{
        TextView day;
        TextView date;
        CardView rootCard;

        public DaysViewHolder(@NonNull View itemView) {
            super(itemView);

            day=itemView.findViewById(R.id.day_name);
            date=itemView.findViewById(R.id.date_dayitem);
            rootCard=itemView.findViewById(R.id.rootCard);

        }
    }
}
