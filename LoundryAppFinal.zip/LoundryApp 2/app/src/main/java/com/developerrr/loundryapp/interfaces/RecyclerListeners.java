package com.developerrr.loundryapp.interfaces;



//
public interface RecyclerListeners {

    void OnItemCLick(int position);
}
