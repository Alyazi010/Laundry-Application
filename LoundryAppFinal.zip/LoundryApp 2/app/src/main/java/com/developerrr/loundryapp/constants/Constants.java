package com.developerrr.loundryapp.constants;

public class Constants {
// this code constant key to retervie to local data

    //shared preferences file name
    public static String prefsName="localPrefs";

    //location coordinates
    public static String latitude="latitude";
    public static String longitude="longitude";

    //address details
    public static String addressType="addressType";
    public static String addressBuilding="addressbuilding";
    public static String addressAppartment="addressappartment";
    public static String addressNotes="addressnotes";

    //order type
    public static String orderType="ordertype";


    //order pickup date and time
    public static String pickUpdAY="pickUpday";
    public static String pickUpdate="pickUpdate";
    public static String pickUpfrom="pickUpfrom";
    public static String pickUpto="pickUpto";


    public static String dropdAY="dropday";
    public static String dropdate="dropdate";
    public static String dropfrom="dropfrom";
    public static String dropto="dropto";

}
