package com.developerrr.loundryapp.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.cardview.widget.CardView;

import com.developerrr.loundryapp.InstructionsActivity;
import com.developerrr.loundryapp.R;
import com.developerrr.loundryapp.models.ExpandableItem;

import java.util.List;
//this code to expand the list
public class ExpandableListAdapter extends BaseAdapter {
    List<ExpandableItem> items;
    Context context;

    public ExpandableListAdapter(List<ExpandableItem> items, Context context) {
        this.items = items;
        this.context = context;
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public Object getItem(int i) {
        return items.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        if(view==null) {
            view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.expandable_listview_item, viewGroup, false);
        }
        TextView name=view.findViewById(R.id.item_textView);

        name.setText(items.get(i).getName());

        return view;
    }
}
